#!/bin/bash

./1.parentcall.sh
./2.filtering.sh
./3.separatechromosomes.sh
./4.ordermarkers.sh
./5.postprocess.sh
